package com.zorion.jarvis

import android.content.Context
import android.graphics.*
import android.view.View
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/** JARVIS-style HUD. mode: 0 idle, 1 listening, 2 thinking, 3 speaking */
class Hud(c: Context, private val logo: Bitmap) : View(c) {
    var mode = 0
    var level = 0f
    var left = ""
    var right = ""
    var caption = ""

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val d = resources.displayMetrics.density
    private val rect = RectF()
    private var t = 0f
    private var lv = 0f
    private var glow: RadialGradient? = null
    private var glowKey = 0L
    private val names = arrayOf("STANDBY", "LISTENING", "PROCESSING", "SPEAKING")

    private fun modeColor(): Int = when (mode) {
        1 -> 0xFF7CFF6B
        2 -> 0xFFB388FF
        3 -> 0xFFFFB300
        else -> 0xFF29E0FF
    }.toInt()

    override fun onDraw(cv: Canvas) {
        t += 0.02f
        lv += (level - lv) * 0.2f
        val w = width.toFloat(); val h = height.toFloat()
        val cx = w / 2; val cy = h / 2 - 8 * d
        val base = min(w, h) * 0.25f
        val col = modeColor()
        val rgb = col and 0x00FFFFFF
        val boost = lv + (if (mode == 3) 0.5f + 0.4f * sin(t * 8) else if (mode == 2) 0.25f + 0.2f * sin(t * 5) else 0f)

        // soft radial glow
        val key = col.toLong() * 31 + (base * 10).toLong() + (cy * 7).toLong()
        if (glow == null || key != glowKey) {
            glowKey = key
            glow = RadialGradient(cx, cy, base * 2.2f, rgb or 0x66000000, rgb, Shader.TileMode.CLAMP)
        }
        p.reset(); p.isAntiAlias = true
        p.style = Paint.Style.FILL; p.shader = glow; p.alpha = (110 + 120 * boost).toInt().coerceIn(0, 255)
        cv.drawCircle(cx, cy, base * 2.2f, p)
        p.shader = null

        // scrolling grid
        p.style = Paint.Style.STROKE; p.strokeWidth = 1f; p.color = 0x1829E0FF
        val gs = 28 * d; val off = (t * 12 * d) % gs
        var x = 0f; while (x < w) { cv.drawLine(x, 0f, x, h, p); x += gs }
        var y = off - gs; while (y < h) { cv.drawLine(0f, y, w, y, p); y += gs }

        // rotating arc-reactor rings
        p.strokeCap = Paint.Cap.ROUND
        for (i in 0..3) {
            val r = base * (1.0f + i * 0.2f)
            p.strokeWidth = (5 - i) * d; p.color = col; p.alpha = 230 - i * 40
            val s = t * 50f * (if (i % 2 == 0) 1 else -1) * (1 + i * 0.5f)
            rect.set(cx - r, cy - r, cx + r, cy + r)
            cv.drawArc(rect, s, 80f + i * 20f, false, p)
            cv.drawArc(rect, s + 180f, 80f + i * 20f, false, p)
        }

        // tick ring
        p.strokeWidth = 1.5f * d; p.alpha = 150
        val tr = base * 1.95f
        for (i in 0 until 60) {
            val a = (i * 6f + t * 8f) * (PI.toFloat() / 180f)
            val len = if (i % 5 == 0) 9 * d else 4 * d
            cv.drawLine(cx + cos(a) * tr, cy + sin(a) * tr, cx + cos(a) * (tr + len), cy + sin(a) * (tr + len), p)
        }

        // orbiting dots
        p.style = Paint.Style.FILL; p.alpha = 255
        for (i in 0..2) {
            val a = t * (1.2f + i * 0.5f) + i * 2.1f
            val r = base * (1.55f + i * 0.12f)
            cv.drawCircle(cx + cos(a) * r, cy + sin(a) * r, 3 * d, p)
        }

        // core glow + logo
        p.color = col; p.alpha = (40 + 60 * boost).toInt().coerceIn(0, 255)
        cv.drawCircle(cx, cy, base * (0.95f + 0.1f * lv), p)
        p.alpha = 255
        val lr = base * 0.62f
        cv.drawBitmap(logo, null, RectF(cx - lr, cy - lr, cx + lr, cy + lr), p)

        // symmetric waveform
        p.style = Paint.Style.STROKE; p.strokeWidth = 3 * d; p.color = col; p.alpha = 200
        val n = 36; val by = h - 24 * d
        for (i in 0 until n) {
            val amp = ((0.12f + lv * 1.2f + (if (mode == 3) 0.45f else if (mode == 2) 0.2f else 0f)) * abs(sin(t * 4 + i * 0.55f))).coerceAtMost(1f)
            val bx = w * 0.1f + i * (w * 0.8f / n)
            val hh = amp * 14 * d + 1.5f * d
            cv.drawLine(bx, by - hh, bx, by + hh, p)
        }

        // text
        p.style = Paint.Style.FILL; p.textSize = 11 * d; p.color = col; p.alpha = 255; p.typeface = Typeface.MONOSPACE
        p.textAlign = Paint.Align.LEFT; var ly = 18 * d
        for (line in left.split("\n")) { cv.drawText(line, 12 * d, ly, p); ly += 14 * d }
        p.textAlign = Paint.Align.RIGHT; ly = 18 * d
        for (line in right.split("\n")) { cv.drawText(line, w - 12 * d, ly, p); ly += 14 * d }
        p.textAlign = Paint.Align.CENTER; p.textSize = 9 * d; p.alpha = 190
        cv.drawText("● " + names[mode.coerceIn(0, 3)], cx, h - 4 * d, p)
        if (caption.isNotEmpty()) { p.color = 0xFFD8F6FF.toInt(); p.textSize = 13 * d; p.alpha = 255; cv.drawText(caption.takeLast(40), cx, by - 22 * d, p) }
        postInvalidateOnAnimation()
    }
}
