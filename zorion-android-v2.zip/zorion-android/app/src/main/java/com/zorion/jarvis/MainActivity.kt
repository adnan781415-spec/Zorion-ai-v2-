package com.zorion.jarvis

import android.Manifest
import android.animation.Animator
import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.app.ActivityManager
import android.app.Activity
import android.app.AlertDialog
import android.app.DownloadManager
import android.app.Dialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.*
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.hardware.camera2.CameraManager
import android.media.*
import android.net.Uri
import android.os.BatteryManager
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.StatFs
import android.provider.AlarmClock
import android.provider.MediaStore
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.util.Base64
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.widget.*
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

class MainActivity : Activity() {
    private data class P(val url: String, val model: String, val key: String)
    private val groq = "https://api.groq.com/openai/v1"
    private val gem = "https://generativelanguage.googleapis.com/v1beta/openai"

    // normal chat: fast + smart, falls back automatically
    private val chatOrder = listOf(
        P(groq, "openai/gpt-oss-120b", "groq"), P(gem, "gemini-2.5-flash", "gemini"),
        P(groq, "openai/gpt-oss-20b", "groq"), P(gem, "gemini-2.5-flash-lite", "gemini")
    )
    // building games/apps: strongest model first
    private val buildOrder = listOf(
        P(gem, "gemini-2.5-pro", "gemini"), P(gem, "gemini-2.5-flash", "gemini"), P(groq, "openai/gpt-oss-120b", "groq")
    )
    // background jobs (memory extraction / summaries): cheap + quick
    private val cheapOrder = listOf(P(gem, "gemini-2.5-flash-lite", "gemini"), P(groq, "openai/gpt-oss-20b", "groq"))
    private val voices = listOf("Charon", "Algieba", "Orus", "Fenrir", "Puck")

    // theme
    private val BG = 0xFF050B14.toInt()
    private val PANEL = 0xFF0B1626.toInt()
    private val CY = 0xFF29E0FF.toInt()
    private val TXT = 0xFFD8F6FF.toInt()
    private val GREEN = 0xFF7CFF6B.toInt()

    private lateinit var prefs: SharedPreferences
    private lateinit var mem: Memory
    private lateinit var log: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var input: EditText
    private lateinit var hud: Hud
    private lateinit var liveBtn: TextView
    private lateinit var sendBtn: TextView
    private var tts: TextToSpeech? = null
    private var sr: SpeechRecognizer? = null
    private var audio: AudioTrack? = null
    private val main = Handler(Looper.getMainLooper())
    private var live = false
    private var lowWarned = false
    private var lastSeen = 0L
    private var pending: List<String>? = null
    private var pendingVideo = false
    private var lastHtml: String? = null
    private var lastKind = "2d"
    @Volatile private var compacting = false

    private fun msg(role: String, content: String) = JSONObject().put("role", role).put("content", content)

    private fun sys(): String {
        val now = SimpleDateFormat("EEEE, d MMM yyyy, HH:mm", Locale.getDefault()).format(Date())
        return "You are ZORIN-M4 (ZORION), a powerful Jarvis-style AI assistant living on the user's phone. Address the user as 'boss'. " +
            "Speak Hinglish (Hindi in Roman letters mixed with English): calm, confident, refined, dry wit (humor 30%). " +
            "Default replies are SHORT (1-3 sentences) because they are spoken aloud. " +
            "BUT when the user asks for an explanation, steps, a plan, code, comparison or anything detailed, give a complete, accurate, well-organised answer in plain text (light formatting only). " +
            "Think carefully, never invent facts, say honestly when unsure. Use the memory below naturally (never claim you don't remember something that is listed). " +
            "Now: $now." + mem.promptBlock()
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val mk = MasterKey.Builder(this).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
        prefs = EncryptedSharedPreferences.create(
            this, "zorion", mk,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
        mem = Memory(prefs)
        tts = TextToSpeech(this) { st ->
            if (st == TextToSpeech.SUCCESS) {
                val vs = tts?.voices?.filter { it.locale.language == "en" && it.locale.country == "GB" }
                val pick = vs?.firstOrNull { it.name.contains("rjs") || it.name.contains("gbd") } ?: vs?.firstOrNull()
                if (pick != null) tts?.voice = pick else tts?.language = Locale("en", "GB")
                tts?.setPitch(0.8f); tts?.setSpeechRate(0.95f)
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(id: String?) {}
                    override fun onError(id: String?) { spoken() }
                    override fun onDone(id: String?) { spoken() }
                })
            }
        }
        buildUi()
        say("ZORIN-M4 online hai, boss. All systems ready. Bolo, kya karna hai?")
        if (prefs.getString("groq", "").isNullOrBlank() && prefs.getString("gemini", "").isNullOrBlank()) settings()
        shared(intent)
    }

    private val tick = object : Runnable { override fun run() { stats(); main.postDelayed(this, 5000) } }

    override fun onStart() {
        super.onStart()
        if (lastSeen > 0 && System.currentTimeMillis() - lastSeen > 20 * 60000) say("Welcome back, boss.")
        main.post(tick)
    }

    override fun onStop() { lastSeen = System.currentTimeMillis(); main.removeCallbacks(tick); super.onStop() }

    private fun stats() {
        val bm = getSystemService(BATTERY_SERVICE) as BatteryManager
        val bat = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        val st = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))?.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        val chg = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
        val mi = ActivityManager.MemoryInfo(); (getSystemService(ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
        val ram = ((mi.totalMem - mi.availMem) * 100 / mi.totalMem).toInt()
        hud.left = "SYS ONLINE\nBAT $bat%" + (if (chg) " +" else "") + "\nRAM $ram%" + (if (live) "\nLIVE" else "")
        hud.right = SimpleDateFormat("HH:mm\nEEE d MMM", Locale.getDefault()).format(Date())
        if (bat <= 15 && !chg && !lowWarned) { lowWarned = true; say("Boss, battery sirf $bat% reh gayi hai.") }
        if (bat > 20 || chg) lowWarned = false
    }

    private fun report(): String {
        val bm = getSystemService(BATTERY_SERVICE) as BatteryManager
        val mi = ActivityManager.MemoryInfo(); (getSystemService(ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
        val sf = StatFs(Environment.getDataDirectory().path)
        val free = sf.availableBytes / 1_000_000_000
        val tot = sf.totalBytes / 1_000_000_000
        return "Battery ${bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)}%, RAM ${((mi.totalMem - mi.availMem) * 100 / mi.totalMem)}% used, storage mein $free GB free of $tot GB, boss."
    }

    private fun spoken() = runOnUiThread { hud.mode = 0; if (live) main.postDelayed({ listen() }, 400) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    // ================= UI =================
    private fun rounded(color: Int, r: Int, sw: Int = 0, sc: Int = 0) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(r).toFloat(); if (sw > 0) setStroke(dp(sw), sc)
    }

    private fun ripple(d: Drawable): Drawable = RippleDrawable(ColorStateList.valueOf(0x4429E0FF), d, null)

    /** pill-shaped text button */
    private fun tbtn(t: String, size: Float = 13f, onClick: () -> Unit) = TextView(this).apply {
        text = t; textSize = size; setTextColor(CY); gravity = Gravity.CENTER
        setPadding(dp(14), dp(8), dp(14), dp(8))
        background = ripple(rounded(0x2229E0FF, 18, 1, 0x5529E0FF))
        setOnClickListener { onClick() }
    }

    /** round icon button */
    private fun ibtn(t: String, onClick: () -> Unit) = TextView(this).apply {
        text = t; textSize = 18f; gravity = Gravity.CENTER; setTextColor(TXT)
        minWidth = dp(42); minHeight = dp(42)
        background = ripple(rounded(0x00000000, 21))
        setOnClickListener { onClick() }
    }

    private fun buildUi() {
        window.statusBarColor = BG; window.navigationBarColor = BG
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(BG); fitsSystemWindows = true }

        // header
        val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(14), dp(4), dp(6), dp(0)) }
        head.addView(TextView(this).apply {
            text = "ZORION"; setTextColor(CY); textSize = 17f; letterSpacing = 0.25f
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        }, LinearLayout.LayoutParams(0, -2, 1f))
        liveBtn = tbtn("● LIVE", 12f) { toggleLive() }
        head.addView(liveBtn)
        head.addView(ibtn("🧠") { memoryDialog() })
        head.addView(ibtn("📂") { creations() })
        head.addView(ibtn("⚙") { settings() })
        root.addView(head)

        hud = Hud(this, BitmapFactory.decodeResource(resources, R.drawable.zorion))
        hud.setOnClickListener { stopSpeaking(); if (live) listen() }
        root.addView(hud, LinearLayout.LayoutParams(-1, 0, 0.8f))

        log = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(4), dp(12), dp(4)) }
        scroll = ScrollView(this).apply { addView(log); isVerticalScrollBarEnabled = false }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        // quick chips
        val chips = LinearLayout(this).apply { setPadding(dp(8), dp(4), dp(8), dp(4)) }
        listOf("3D racing game banao", "Unreal Engine FPS game banao", "Snake game banao", "Sher ki photo banao", "System status", "Kya yaad hai").forEach { c ->
            chips.addView(tbtn(c, 12f) { handle(c) }, LinearLayout.LayoutParams(-2, -2).apply { setMargins(dp(3), 0, dp(3), 0) })
        }
        root.addView(HorizontalScrollView(this).apply { addView(chips); isHorizontalScrollBarEnabled = false })

        // input bar:  📎 [ text .......... ] 🎤 (➤)
        val bar = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL; setPadding(dp(4), dp(2), dp(4), dp(2))
            background = rounded(PANEL, 26, 1, 0x4429E0FF)
        }
        bar.addView(ibtn("📎") { pick() })
        input = EditText(this).apply {
            hint = "Zorin se bolo…"; setHintTextColor(0xFF6B8BA0.toInt()); setTextColor(TXT); textSize = 15f
            background = null; maxLines = 4
            setRawInputType(InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES)
            imeOptions = EditorInfo.IME_ACTION_SEND
            setHorizontallyScrolling(false)
            setPadding(dp(6), dp(10), dp(6), dp(10))
        }
        bar.addView(input, LinearLayout.LayoutParams(0, -2, 1f))
        bar.addView(ibtn("🎤") { live = false; listen() })
        sendBtn = TextView(this).apply {
            text = "➤"; textSize = 18f; setTextColor(BG); gravity = Gravity.CENTER; alpha = 0.55f
            background = ripple(GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(CY) })
            setOnClickListener { send() }
        }
        bar.addView(sendBtn, LinearLayout.LayoutParams(dp(44), dp(44)).apply { setMargins(dp(4), 0, dp(2), 0) })
        root.addView(bar, LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(10), dp(2), dp(10), dp(8)) })
        setContentView(root)

        input.setOnEditorActionListener { _, id, ev ->
            if (id == EditorInfo.IME_ACTION_SEND || ev?.keyCode == KeyEvent.KEYCODE_ENTER) { send(); true } else false
        }
        input.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) { sendBtn.alpha = if (s.isNullOrBlank() && pending == null) 0.55f else 1f }
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
    }

    private fun bubble(t: String, me: Boolean, pulse: Boolean = false): TextView {
        val tv = TextView(this).apply {
            text = t; textSize = 15f; setTextColor(TXT); setPadding(dp(14), dp(9), dp(14), dp(9))
            setLineSpacing(0f, 1.12f)
            maxWidth = (resources.displayMetrics.widthPixels * 0.82f).toInt()
            background = if (me) GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(0xFF0F4A6B.toInt(), 0xFF0A2E45.toInt())).apply {
                setStroke(dp(1), 0x6629E0FF); cornerRadii = floatArrayOf(dp(16).toFloat(), dp(16).toFloat(), dp(4).toFloat(), dp(4).toFloat(), dp(16).toFloat(), dp(16).toFloat(), dp(16).toFloat(), dp(16).toFloat())
            } else rounded(0xCC0B1626.toInt(), 16, 1, 0x4429E0FF)
            setOnLongClickListener {
                (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("zorion", text))
                Toast.makeText(this@MainActivity, "Copied", Toast.LENGTH_SHORT).show(); true
            }
        }
        log.addView(tv, LinearLayout.LayoutParams(-2, -2).apply { gravity = if (me) Gravity.END else Gravity.START; setMargins(0, dp(4), 0, dp(4)) })
        if (pulse) {
            tv.tag = ObjectAnimator.ofFloat(tv, "alpha", 1f, 0.35f).apply { duration = 700; repeatMode = ValueAnimator.REVERSE; repeatCount = ValueAnimator.INFINITE; start() }
        } else { tv.alpha = 0f; tv.animate().alpha(1f).setDuration(220).start() }
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
        return tv
    }

    private fun thinkBubble(t: String) = bubble(t, false, true)

    /** stop the thinking animation and put the final text */
    private fun settle(tv: TextView, text: String) {
        (tv.tag as? Animator)?.cancel(); tv.tag = null; tv.alpha = 1f; tv.text = text
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun say(t: String) { bubble(t, false); speak(t) }

    private fun actionBubble(label: String, onClick: () -> Unit) {
        log.addView(tbtn(label, 13f, onClick), LinearLayout.LayoutParams(-2, -2).apply { gravity = Gravity.START; setMargins(0, dp(2), 0, dp(2)) })
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun thumb(b: Bitmap) {
        log.addView(ImageView(this).apply { setImageBitmap(b); adjustViewBounds = true; maxWidth = dp(180); background = rounded(PANEL, 12) },
            LinearLayout.LayoutParams(dp(180), -2).apply { gravity = Gravity.END; setMargins(0, dp(4), 0, dp(4)) })
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    // ================= voice output =================
    private fun shorten(t: String): String {
        val clean = t.replace(Regex("[*#`_]"), "")
        if (clean.length <= 320) return clean
        val cut = clean.take(300)
        val end = maxOf(cut.lastIndexOf('.'), cut.lastIndexOf('!'), cut.lastIndexOf('?'), cut.lastIndexOf('\n'))
        return (if (end > 80) cut.take(end + 1) else cut) + " Baaki screen pe hai, boss."
    }

    private fun speak(t: String) {
        stopSpeaking(); hud.mode = 3
        val clean = shorten(t)
        if (prefs.getBoolean("gv", true) && !prefs.getString("gemini", "").isNullOrBlank()) {
            Thread {
                val pcm = try { geminiTts(clean) } catch (e: Exception) { null }
                runOnUiThread { if (pcm != null) play(pcm) else sysSpeak(clean) }
            }.start()
        } else sysSpeak(clean)
    }

    private fun sysSpeak(t: String) {
        val r = tts?.speak(t, TextToSpeech.QUEUE_FLUSH, null, "z")
        if (r != TextToSpeech.SUCCESS) spoken()
    }

    private fun stopSpeaking() {
        tts?.stop()
        audio?.let { try { it.stop(); it.release() } catch (e: Exception) { } }
        audio = null; hud.mode = 0
    }

    private fun geminiTts(text: String): ByteArray? {
        val key = prefs.getString("gemini", "") ?: return null
        val voice = prefs.getString("voice", "Charon") ?: "Charon"
        val prompt = "Say in a calm, refined British male AI butler voice, understated, dry wit, natural pace: $text"
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", prompt)))))
            .put("generationConfig", JSONObject().put("responseModalities", JSONArray().put("AUDIO"))
                .put("speechConfig", JSONObject().put("voiceConfig", JSONObject().put("prebuiltVoiceConfig", JSONObject().put("voiceName", voice)))))
        val c = URL("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-preview-tts:generateContent")
            .openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.doOutput = true; c.connectTimeout = 8000; c.readTimeout = 20000
        c.setRequestProperty("Content-Type", "application/json"); c.setRequestProperty("x-goog-api-key", key)
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        if (c.responseCode !in 200..299) return null
        val d = JSONObject(c.inputStream.bufferedReader().readText()).getJSONArray("candidates").getJSONObject(0)
            .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getJSONObject("inlineData").getString("data")
        return Base64.decode(d, Base64.DEFAULT)
    }

    private fun play(pcm: ByteArray) {
        val tr = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(24000).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setBufferSizeInBytes(pcm.size).setTransferMode(AudioTrack.MODE_STATIC).build()
        tr.write(pcm, 0, pcm.size)
        tr.setNotificationMarkerPosition(pcm.size / 2)
        tr.setPlaybackPositionUpdateListener(object : AudioTrack.OnPlaybackPositionUpdateListener {
            override fun onMarkerReached(t: AudioTrack?) { try { tr.release() } catch (e: Exception) { }; spoken() }
            override fun onPeriodicNotification(t: AudioTrack?) {}
        })
        audio = tr; hud.mode = 3; tr.play()
    }

    // ================= dialogs =================
    private fun darkDialog() = AlertDialog.Builder(this, AlertDialog.THEME_DEVICE_DEFAULT_DARK)

    private fun settings() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(10), dp(20), 0) }
        fun field(h: String, k: String) = EditText(this).apply {
            hint = h + if (!prefs.getString(k, "").isNullOrBlank()) " (saved ✓)" else ""
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        val g = field("Groq API key", "groq"); val m = field("Gemini API key", "gemini")
        val gv = CheckBox(this).apply { text = "Jarvis voice (Gemini)"; isChecked = prefs.getBoolean("gv", true) }
        val am = CheckBox(this).apply { text = "Auto-memory (khud important baatein yaad rakhe)"; isChecked = prefs.getBoolean("auto", true) }
        val sp = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, voices)
            setSelection(voices.indexOf(prefs.getString("voice", "Charon")).coerceAtLeast(0))
        }
        box.addView(g); box.addView(m); box.addView(gv); box.addView(am); box.addView(sp)
        darkDialog().setTitle("ZORIN-M4 settings").setView(ScrollView(this).apply { addView(box) })
            .setPositiveButton("Save") { _, _ ->
                val e = prefs.edit()
                if (g.text.isNotBlank()) e.putString("groq", g.text.toString().trim())
                if (m.text.isNotBlank()) e.putString("gemini", m.text.toString().trim())
                e.putBoolean("gv", gv.isChecked).putBoolean("auto", am.isChecked).putString("voice", voices[sp.selectedItemPosition]).apply()
            }.setNegativeButton("Cancel", null).show()
    }

    private fun memoryDialog() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(8), dp(16), 0) }
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        fun refresh() {
            list.removeAllViews()
            if (mem.summary.isNotBlank()) list.addView(TextView(this@MainActivity).apply {
                text = "📝 Purani baaton ka summary:\n${mem.summary}"; setTextColor(0xFF8FB3C7.toInt()); textSize = 13f; setPadding(0, 0, 0, dp(10))
            })
            val facts = mem.snapshot()
            if (facts.isEmpty()) list.addView(TextView(this@MainActivity).apply { text = "Abhi kuch yaad nahi hai."; setTextColor(0xFF8FB3C7.toInt()) })
            facts.forEachIndexed { i, f ->
                val r = LinearLayout(this@MainActivity).apply { gravity = Gravity.CENTER_VERTICAL }
                r.addView(TextView(this@MainActivity).apply { text = "• $f"; setTextColor(TXT); textSize = 14f }, LinearLayout.LayoutParams(0, -2, 1f))
                r.addView(ibtn("✕") { mem.removeAt(i); refresh() })
                list.addView(r)
            }
        }
        refresh()
        val add = EditText(this).apply { hint = "Nayi baat yaad karao…"; setHintTextColor(0xFF6B8BA0.toInt()); setTextColor(TXT) }
        val addRow = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(8), 0, 0) }
        addRow.addView(add, LinearLayout.LayoutParams(0, -2, 1f))
        addRow.addView(tbtn("Add") { if (mem.addFact(add.text.toString())) { add.setText(""); refresh() } })
        box.addView(list); box.addView(addRow)
        darkDialog().setTitle("🧠 ZORION ki yaaddasht").setView(ScrollView(this).apply { addView(box) })
            .setPositiveButton("Done", null)
            .setNeutralButton("Sab bhula do") { _, _ -> mem.clearAll(); say("Sab bhool gaya, boss.") }.show()
    }

    private fun showText(title: String, body: String) {
        darkDialog().setTitle(title).setView(ScrollView(this).apply {
            addView(TextView(this@MainActivity).apply { text = body; setTextColor(TXT); textSize = 13f; typeface = Typeface.MONOSPACE; setPadding(dp(16), dp(8), dp(16), dp(8)); setTextIsSelectable(true) })
        }).setPositiveButton("OK", null).show()
    }

    // ================= voice input / LIVE =================
    private fun toggleLive() {
        live = !live
        liveBtn.setTextColor(if (live) GREEN else CY)
        liveBtn.background = ripple(rounded(if (live) 0x337CFF6B else 0x2229E0FF, 18, 1, if (live) 0xAA7CFF6B.toInt() else 0x5529E0FF))
        if (live) listen() else { sr?.cancel(); stopSpeaking() }
    }

    private fun listen() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 2); return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { live = false; say("Boss, is phone pe voice recognition available nahi hai."); return }
        if (sr == null) {
            sr = SpeechRecognizer.createSpeechRecognizer(this)
            sr!!.setRecognitionListener(object : RecognitionListener {
                override fun onResults(b: Bundle?) {
                    hud.caption = ""
                    val t = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (t != null) handle(t) else again()
                }
                override fun onError(e: Int) {
                    hud.mode = 0; hud.caption = ""
                    if (e == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) live = false
                    else { if (e == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) sr?.cancel(); again() }
                }
                override fun onRmsChanged(v: Float) { hud.level = ((v + 2f) / 12f).coerceIn(0f, 1f) }
                override fun onPartialResults(b: Bundle?) { hud.caption = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: "" }
                override fun onReadyForSpeech(p: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() { hud.level = 0f }
                override fun onEvent(t: Int, b: Bundle?) {}
            })
        }
        hud.mode = 1
        sr!!.startListening(
            Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
                .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        )
    }

    private fun again() { if (live) main.postDelayed({ listen() }, 1200) }

    override fun onRequestPermissionsResult(code: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(code, p, r)
        if (code == 2 && r.firstOrNull() == PackageManager.PERMISSION_GRANTED) listen()
    }

    // ================= SEND =================
    private fun send() {
        var q = input.text.toString().trim()
        if (q.isEmpty() && pending == null) { Toast.makeText(this, "Pehle kuch likho, boss", Toast.LENGTH_SHORT).show(); return }
        if (q.isEmpty()) q = "Isme kya hai? Detail mein batao."
        input.setText("")
        sendBtn.alpha = 0.55f
        handle(q)
    }

    private fun handle(q0: String) {
        val q = q0.replace(Regex("(?i)\\b(zorin|zorion|ज़ोरिन|जोरिन)\\b[, ]*"), "").trim()
        if (q.isEmpty()) { if (q0.isNotBlank()) say("Ji boss?") else again(); return }
        bubble(q, true)
        val att = pending
        if (att != null) {
            pending = null; hud.mode = 2
            val tv = thinkBubble("…")
            Thread { val a = vision(q, att); runOnUiThread { settle(tv, a); speak(a) } }.start(); return
        }
        val edit = lastHtml != null && Regex("^(change|badlo|badal|modify|fix|isme)\\b").containsMatchIn(q.lowercase())
        if (edit || isBuild(q)) { build(q, edit); return }
        if (isImage(q)) { genImage(q); return }
        val r = try { local(q) } catch (e: Exception) { "Ye action fail ho gaya, boss: ${e.message}" }
        if (r != null) { say(r); return }
        hud.mode = 2
        val tv = thinkBubble("…")
        Thread {
            val a = chat(q)
            runOnUiThread { settle(tv, a); speak(a) }
        }.start()
    }

    private fun go(i: Intent) { i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(i) }

    private fun media(code: Int) {
        val am = getSystemService(AUDIO_SERVICE) as AudioManager
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code)); am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }

    private fun local(q: String): String? {
        val l = q.lowercase()
        // ---- memory commands ----
        if (Regex("forget everything|sab bhool ja|sab bhul ja").containsMatchIn(l)) { mem.clearAll(); return "Sab bhool gaya, boss." }
        Regex("(?i)^(?:remember(?: that)?|yaad rakh(?:o|na)?)\\s+(.+)").find(q)?.let {
            return if (mem.addFact(it.groupValues[1])) "Yaad rakh liya, boss." else "Ye toh pehle se yaad hai, boss."
        }
        Regex("(?i)^(?:forget|bhool ja|bhul ja)\\s+(.+)").find(q)?.let {
            val n = mem.forget(it.groupValues[1].trim()); return if (n > 0) "$n baat(ein) bhula di, boss." else "Aisa kuch yaad nahi tha, boss."
        }
        if (Regex("what do you remember|kya yaad hai").containsMatchIn(l)) {
            val f = mem.snapshot()
            return if (f.isEmpty()) "Abhi kuch yaad nahi hai, boss." else f.mapIndexed { i, s -> "${i + 1}. $s" }.joinToString("\n")
        }
        if (Regex("memory (dikhao|kholo|show|manage)|meri yaadein").containsMatchIn(l)) { memoryDialog(); return "Ye lo, boss." }
        // ---- phone control ----
        if (Regex("system status|battery|\\bram\\b|storage").containsMatchIn(l)) return report()
        if (Regex("screenshot").containsMatchIn(l)) return "Boss, app se screenshot nahi le sakta. Power plus volume down dabao."
        if (Regex("downloads").containsMatchIn(l) && Regex("open|kholo|khol").containsMatchIn(l)) { go(Intent(DownloadManager.ACTION_VIEW_DOWNLOADS)); return "Downloads khol raha hoon." }
        Regex("volume\\s+(up|down)").find(l)?.let {
            (getSystemService(AUDIO_SERVICE) as AudioManager).adjustStreamVolume(AudioManager.STREAM_MUSIC,
                if (it.groupValues[1] == "up") AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI); return "Done, boss."
        }
        if (Regex("pause music|music pause|stop music").containsMatchIn(l)) { media(KeyEvent.KEYCODE_MEDIA_PAUSE); return "Music pause." }
        if (Regex("resume music|play music").containsMatchIn(l)) { media(KeyEvent.KEYCODE_MEDIA_PLAY); return "Music chala diya." }
        if (Regex("next song|next track").containsMatchIn(l)) { media(KeyEvent.KEYCODE_MEDIA_NEXT); return "Next song." }
        Regex("(?:call|dial)\\s+(\\+?[\\d ]{5,})").find(l)?.let {
            go(Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + it.groupValues[1].replace(" ", "")))); return "Dial kar raha hoon, boss. Call button dabao."
        }
        Regex("(?:sms|text)\\s+(\\+?\\d{5,})\\s+(.+)").find(l)?.let {
            go(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + it.groupValues[1])).putExtra("sms_body", it.groupValues[2])); return "Message ready hai, send dabao."
        }
        Regex("whatsapp\\s+(\\+?\\d{5,})\\s+(.+)").find(l)?.let {
            go(Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/" + it.groupValues[1].removePrefix("+") + "?text=" + Uri.encode(it.groupValues[2])))); return "WhatsApp khol raha hoon."
        }
        Regex("(?:navigate to|directions to)\\s+(.+)").find(l)?.let { go(Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=" + Uri.encode(it.groupValues[1])))); return "Navigation shuru, boss." }
        Regex("^(?:search|google)\\s+(.+)").find(l)?.let { go(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(it.groupValues[1])))); return "Search kar raha hoon." }
        Regex("^play\\s+(.+)").find(l)?.let { go(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(it.groupValues[1])))); return "YouTube pe chala raha hoon." }
        Regex("alarm\\s+(?:at\\s+)?(\\d{1,2})[: ](\\d{2})").find(l)?.let {
            go(Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_HOUR, it.groupValues[1].toInt())
                .putExtra(AlarmClock.EXTRA_MINUTES, it.groupValues[2].toInt()).putExtra(AlarmClock.EXTRA_SKIP_UI, true))
            return "Alarm set, ${it.groupValues[1]}:${it.groupValues[2]} pe."
        }
        Regex("timer\\s+(\\d+)\\s*(min|sec)").find(l)?.let {
            val s = it.groupValues[1].toInt() * (if (it.groupValues[2] == "min") 60 else 1)
            go(Intent(AlarmClock.ACTION_SET_TIMER).putExtra(AlarmClock.EXTRA_LENGTH, s).putExtra(AlarmClock.EXTRA_SKIP_UI, true)); return "Timer start, boss."
        }
        if (Regex("flashlight|torch").containsMatchIn(l)) {
            val on = !Regex("\\boff\\b|band").containsMatchIn(l)
            val cm = getSystemService(Context.CAMERA_SERVICE) as CameraManager
            cm.setTorchMode(cm.cameraIdList[0], on); return if (on) "Torch on." else "Torch off."
        }
        if (l.contains("wifi")) { go(Intent(Settings.ACTION_WIFI_SETTINGS)); return "Wi-Fi settings khol di." }
        if (l.contains("bluetooth")) { go(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)); return "Bluetooth settings khol di." }
        if (Regex("\\b(time|samay)\\b").containsMatchIn(l)) return SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date()) + " ho rahe hain, boss."
        val name = (Regex("^open\\s+(.+)").find(l)?.groupValues?.get(1)
            ?: Regex("^(.+?)\\s+(?:kholo|khol do|open karo)$").find(l)?.groupValues?.get(1))?.trim()
        if (name != null) {
            val pm = packageManager
            val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            val hit = apps.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(name) }
            val i = hit?.let { pm.getLaunchIntentForPackage(it.activityInfo.packageName) }
            return if (i != null) { go(i); "${hit.loadLabel(pm)} khol raha hoon." } else "$name naam ka app nahi mila, boss."
        }
        return null
    }

    // ================= photos / videos IN (attach, or Share -> ZORION) =================
    private fun pick() {
        startActivityForResult(Intent(Intent.ACTION_GET_CONTENT).setType("*/*")
            .putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("image/*", "video/*")).addCategory(Intent.CATEGORY_OPENABLE), 7)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(r: Int, c: Int, d: Intent?) {
        super.onActivityResult(r, c, d)
        if (r == 7 && c == RESULT_OK) d?.data?.let { attach(it) }
    }

    override fun onNewIntent(i: Intent?) { super.onNewIntent(i); i?.let { shared(it) } }

    @Suppress("DEPRECATION")
    private fun shared(i: Intent) {
        if (i.action != Intent.ACTION_SEND) return
        val u = i.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)
        if (u != null) attach(u)
        else i.getStringExtra(Intent.EXTRA_TEXT)?.let { input.setText(it); input.setSelection(it.length) }
    }

    private fun b64(b: Bitmap, max: Int = 1024): String {
        val k = max.toFloat() / maxOf(b.width, b.height)
        val bb = if (k < 1f) Bitmap.createScaledBitmap(b, (b.width * k).toInt(), (b.height * k).toInt(), true) else b
        val o = ByteArrayOutputStream(); bb.compress(Bitmap.CompressFormat.JPEG, 80, o)
        return Base64.encodeToString(o.toByteArray(), Base64.NO_WRAP)
    }

    private fun attach(u: Uri) {
        Thread {
            val frames = mutableListOf<String>(); var video = false
            try {
                if ((contentResolver.getType(u) ?: "").startsWith("video")) {
                    video = true
                    val mr = MediaMetadataRetriever(); mr.setDataSource(this, u)
                    val dur = (mr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION) ?: "0").toLong() * 1000
                    for (k in 0 until 4) mr.getFrameAtTime(dur * k / 4 + 100000, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)?.let { frames.add(b64(it, 768)) }
                    mr.release()
                } else {
                    val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                    contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, o) }
                    o.inJustDecodeBounds = false; o.inSampleSize = maxOf(1, maxOf(o.outWidth, o.outHeight) / 1536)
                    contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, o) }?.let { frames.add(b64(it)) }
                }
            } catch (e: Exception) { }
            runOnUiThread {
                if (frames.isEmpty()) say("Boss, ye file nahi padh paaya.")
                else {
                    pending = frames; pendingVideo = video; sendBtn.alpha = 1f
                    val bytes = Base64.decode(frames[0], Base64.NO_WRAP)
                    BitmapFactory.decodeByteArray(bytes, 0, bytes.size)?.let { thumb(it) }
                    say((if (video) "Video" else "Photo") + " mil gayi, boss. Ab bolo ya likho, kya karna hai iska?")
                }
            }
        }.start()
    }

    // ================= AI core =================
    private fun openai(base: String, key: String, model: String, msgs: JSONArray, maxTok: Int, timeout: Int): String {
        val c = URL("$base/chat/completions").openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.doOutput = true; c.connectTimeout = 15000; c.readTimeout = timeout
        c.setRequestProperty("Content-Type", "application/json"); c.setRequestProperty("Authorization", "Bearer $key")
        c.outputStream.use { it.write(JSONObject().put("model", model).put("messages", msgs).put("max_tokens", maxTok).toString().toByteArray()) }
        val ok = c.responseCode in 200..299
        val txt = (if (ok) c.inputStream else c.errorStream)?.bufferedReader()?.readText() ?: ""
        if (!ok) throw Exception("HTTP ${c.responseCode}")
        val out = JSONObject(txt).getJSONArray("choices").getJSONObject(0).getJSONObject("message").optString("content", "").trim()
        if (out.isEmpty()) throw Exception("empty reply")
        return out
    }

    /** try each provider in order until one answers. Throws "NOKEY" if no key is saved at all. */
    private fun llm(msgs: JSONArray, maxTok: Int, timeout: Int, order: List<P>): String {
        var err = ""; var tried = false
        for (p in order) {
            val k = prefs.getString(p.key, "") ?: ""
            if (k.isBlank()) continue
            tried = true
            try { return openai(p.url, k, p.model, msgs, maxTok, timeout) } catch (e: Exception) { err = "${p.model}: ${e.message}" }
        }
        throw Exception(if (!tried) "NOKEY" else err)
    }

    private fun vision(q: String, imgs: List<String>): String {
        val key = prefs.getString("gemini", "") ?: ""
        if (key.isBlank()) return "Boss, photo ya video dekhne ke liye Gemini key chahiye (⚙)."
        val content = JSONArray().put(JSONObject().put("type", "text").put("text", (if (pendingVideo) "These are 4 frames from one video, in order. " else "") + q))
        imgs.forEach { content.put(JSONObject().put("type", "image_url").put("image_url", JSONObject().put("url", "data:image/jpeg;base64,$it"))) }
        val msgs = JSONArray().put(msg("system", sys())).put(JSONObject().put("role", "user").put("content", content))
        return try { openai(gem, key, "gemini-2.5-flash", msgs, 3000, 60000) } catch (e: Exception) { "Dekh nahi paaya, boss. (${e.message})" }
    }

    private fun chat(q: String): String {
        val msgs = JSONArray().put(msg("system", sys()))
        mem.recent(24).forEach { msgs.put(msg(it.first, it.second)) }
        msgs.put(msg("user", q))
        return try {
            val a = llm(msgs, 6000, 45000, chatOrder)
            mem.addTurn(q, a)
            Thread { afterTurn(q, a) }.start()
            a
        } catch (e: Exception) {
            if (e.message == "NOKEY") "Boss, pehle settings (⚙) mein API key daalo." else "Sab providers fail ho gaye, boss. (${e.message})"
        }
    }

    // ---------- smart memory ----------
    private fun afterTurn(q: String, a: String) {
        if (prefs.getBoolean("auto", true) && q.length >= 15) learn(q, a)
        if (mem.historySize() > 60 && !compacting) compact()
    }

    /** ask a cheap model to pull out durable facts about the user */
    private fun learn(q: String, a: String) {
        try {
            val known = mem.snapshot().joinToString("\n") { "- $it" }
            val m = JSONArray()
                .put(msg("system", "Extract NEW durable personal facts about the USER worth remembering long-term (name, family, job, city, preferences, projects, goals, routines, important dates, likes/dislikes) from the exchange below. " +
                    "Ignore trivia, general questions and temporary requests. Write each as a short line in Hinglish like 'Boss ka naam Rahul hai'. Do not repeat known facts. " +
                    "Reply with ONLY a JSON array of strings, or [] if nothing.\nKnown facts:\n$known"))
                .put(msg("user", "User: $q\nAssistant: $a"))
            val t = llm(m, 1000, 25000, cheapOrder)
            val js = Regex("\\[[\\s\\S]*\\]").find(t)?.value ?: return
            val arr = JSONArray(js)
            for (i in 0 until arr.length()) mem.addFact(arr.optString(i))
        } catch (e: Exception) { }
    }

    /** fold the oldest messages into the rolling summary so context never overflows */
    private fun compact() {
        compacting = true
        try {
            val old = mem.oldest(30)
            val text = old.joinToString("\n") { "${it.first}: ${it.second}" }
            val m = JSONArray()
                .put(msg("system", "Merge the previous summary and the conversation into ONE compact summary (max 150 words) keeping facts, decisions, user preferences and ongoing tasks. Hinglish. Reply with only the summary."))
                .put(msg("user", "Previous summary:\n${mem.summary}\n\nConversation:\n$text"))
            val s = llm(m, 1500, 30000, cheapOrder)
            mem.compact(30, s.trim())
        } catch (e: Exception) { } finally { compacting = false }
    }

    // ================= build games / apps =================
    private fun isBuild(q: String): Boolean {
        val l = q.lowercase()
        val thing = Regex("\\b(game|app|website|calculator|tool|quiz|simulator|simulation|animation|level)\\b|गेम|ऐप").containsMatchIn(l) || Regex("unreal|\\bue ?5\\b").containsMatchIn(l)
        val make = Regex("banao|bana do|bana de|banana|banaiye|\\bbuild\\b|\\bmake\\b|\\bcreate\\b|develop|बनाओ|बना दो|बनाइए").containsMatchIn(l)
        return thing && make && !l.contains("open ")
    }

    private fun kindOf(q: String): String {
        val l = q.lowercase()
        return when {
            Regex("unreal|\\bue ?5\\b").containsMatchIn(l) -> "ue5"
            Regex("\\b3 ?d\\b|three ?d|\\bfps\\b|racing|shooter|open world|thriller").containsMatchIn(l) -> "3d"
            else -> "2d"
        }
    }

    private val htmlRules = "Output ONE complete self-contained HTML file (inline CSS+JS). Mobile-first, full-screen canvas, responsive, touch controls (on-screen joystick/buttons) plus keyboard, smooth 60fps. " +
        "Make it SPECTACULAR and intense (khatarnak): dark neon visuals, particles, screen shake, glow, WebAudio sound effects, start screen, HUD (score/health/level), game-over + restart, difficulty that ramps up, high-score kept in memory. " +
        "Everything must actually work - no placeholders, no TODOs, no missing assets (draw everything procedurally). Return ONLY the code in a single ```html block."

    private fun codegenSys(kind: String) = if (kind == "3d")
        "You are a world-class 3D game developer. Build the requested game in 3D using three.js r128 loaded ONLY via <script src=\"https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js\"></script>. " +
            "Do not use OrbitControls, CapsuleGeometry or any external models/textures: build all geometry procedurally (boxes, spheres, cylinders, custom meshes), use fog, lights, emissive materials, particle effects, cap pixel ratio at 2, dispose/reuse objects for performance. " + htmlRules
    else "You are an expert game and app developer. No external libraries. " + htmlRules

    private fun build(q: String, edit: Boolean) {
        hud.mode = 2
        val kind = if (edit) lastKind else kindOf(q)
        if (kind == "ue5") { buildUe(q); return }
        val tv = thinkBubble(if (kind == "3d") "3D game bana raha hoon, boss… (2-3 minute lag sakte hain)" else "Bana raha hoon, boss… (1-2 minute lag sakte hain)")
        val prev = if (edit) lastHtml else null
        Thread {
            var err = ""
            val res = try { codegen(q, prev, kind) } catch (e: Exception) { err = e.message ?: ""; null }
            runOnUiThread {
                if (res == null) {
                    val m = if (err == "NOKEY") "Boss, pehle settings (⚙) mein API key daalo." else "Build fail ho gaya, boss. Phir se try karo."
                    settle(tv, m); speak(m)
                } else {
                    lastHtml = res; lastKind = kind; saveBuild(res)
                    settle(tv, "Ready hai, boss!"); speak("Ready hai, boss."); showHtml(res); actionBubble("▶ Open again") { showHtml(res) }
                }
            }
        }.start()
    }

    private fun codegen(q: String, prev: String?, kind: String): String? {
        val user = if (prev != null) "Current file:\n$prev\n\nApply this change and return the full updated file: $q" else q
        val msgs = JSONArray().put(msg("system", codegenSys(kind))).put(msg("user", user))
        val t = llm(msgs, 32000, 280000, buildOrder)
        val m = Regex("```(?:html)?\\s*([\\s\\S]*?)```").find(t)
        val code = (m?.groupValues?.get(1) ?: t.removePrefix("```html").removePrefix("```")).trim()
        return if (code.contains("<script", true) || code.contains("<html", true)) code else null
    }

    private fun buildsDir() = File(filesDir, "builds").apply { mkdirs() }

    private fun saveBuild(html: String) {
        try {
            val t = Regex("<title>(.*?)</title>", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL)).find(html)?.groupValues?.get(1)
                ?.trim()?.replace(Regex("[^A-Za-z0-9 -]"), "")?.take(28) ?: ""
            File(buildsDir(), "${System.currentTimeMillis()}__${t.ifBlank { "creation" }}.html").writeText(html)
        } catch (e: Exception) { }
    }

    private fun creations() {
        val fs = buildsDir().listFiles()?.filter { it.extension == "html" }?.sortedByDescending { it.name } ?: emptyList()
        if (fs.isEmpty()) { say("Abhi tak kuch nahi banaya, boss. Bolo 'racing game banao'."); return }
        val names = fs.map {
            val n = it.name.removeSuffix(".html")
            val ts = n.substringBefore("__").toLongOrNull() ?: 0L
            n.substringAfter("__", "creation") + "  ·  " + SimpleDateFormat("d MMM HH:mm", Locale.getDefault()).format(Date(ts))
        }
        darkDialog().setTitle("📂 Meri creations").setItems(names.toTypedArray()) { _, i ->
            try { val h = fs[i].readText(); lastHtml = h; showHtml(h) } catch (e: Exception) { }
        }.setNegativeButton("Close", null).setNeutralButton("Sab delete") { _, _ -> fs.forEach { it.delete() } }.show()
    }

    private fun showHtml(html: String) {
        val dlg = Dialog(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen)
        dlg.window?.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; fitsSystemWindows = true; setBackgroundColor(BG) }
        val wv = WebView(this).apply {
            settings.javaScriptEnabled = true; settings.domStorageEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false; settings.allowFileAccess = false
            webChromeClient = WebChromeClient(); setBackgroundColor(0xFF000000.toInt())
            loadDataWithBaseURL("https://zorion.local/", html, "text/html", "utf-8", null)
        }
        val bar = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(dp(6), dp(4), dp(6), dp(4)); setBackgroundColor(0xFF08121F.toInt()) }
        val lp = { LinearLayout.LayoutParams(-2, -2).apply { setMargins(dp(3), 0, dp(3), 0) } }
        bar.addView(tbtn("✕ Close", 13f) { dlg.dismiss() }, lp())
        bar.addView(tbtn("⟳", 13f) { wv.loadDataWithBaseURL("https://zorion.local/", html, "text/html", "utf-8", null) }, lp())
        bar.addView(tbtn("⬇ Save", 13f) { saveHtml(html)?.let { Toast.makeText(this, "Downloads/ZORION mein save", Toast.LENGTH_SHORT).show() } }, lp())
        bar.addView(tbtn("↗ Share", 13f) { saveHtml(html)?.let { shareUri(it, "text/html") } }, lp())
        box.addView(bar); box.addView(wv, LinearLayout.LayoutParams(-1, 0, 1f))
        dlg.setOnDismissListener { wv.loadUrl("about:blank"); wv.destroy() }
        dlg.setContentView(box); dlg.show()
    }

    private fun saveHtml(html: String): Uri? {
        val cv = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "zorion_${System.currentTimeMillis()}.html")
            put(MediaStore.MediaColumns.MIME_TYPE, "text/html"); put(MediaStore.MediaColumns.RELATIVE_PATH, "Download/ZORION")
        }
        val u = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv) ?: return null
        contentResolver.openOutputStream(u)?.use { it.write(html.toByteArray()) }
        return u
    }

    private fun shareUri(u: Uri, type: String) {
        startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType(type).putExtra(Intent.EXTRA_STREAM, u)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION), "Share"))
    }

    // ================= Unreal Engine 5 project generator =================
    // UE5 itself runs on a PC (Windows/Mac/Linux). The phone cannot run the engine, so ZORION writes a complete
    // UE5 C++ project (zip) which you copy to your PC and open with the Unreal Editor.
    private val ueSys = "You are a senior Unreal Engine 5.4 C++ gameplay programmer. Create a COMPLETE, compilable UE5 C++ project for the game the user asks for. " +
        "Pick a short PascalCase project name. Output EVERY file in exactly this format and nothing else:\n=== FILE: relative/path ===\n<file content>\n" +
        "Required files: <Name>.uproject (EngineAssociation \"5.4\", one Runtime module), Source/<Name>.Target.cs, Source/<Name>Editor.Target.cs, Source/<Name>/<Name>.Build.cs, " +
        "Source/<Name>/<Name>.h and .cpp (IMPLEMENT_PRIMARY_GAME_MODULE), a GameMode, a player Character with input (Enhanced Input set up in code, no assets needed), at least two more gameplay classes " +
        "(enemy AI, pickup, weapon/projectile, spawner...), a HUD, Config/DefaultEngine.ini (set GameDefaultMap to /Game/Maps/Main and GlobalDefaultGameMode), " +
        "Content/Python/setup_level.py (Unreal editor Python using only the `unreal` module that creates and saves the map /Game/Maps/Main with floor, lights, player start and spawners), and README.md with exact numbered steps (generate VS project files, build, run the python script, press Play). " +
        "Make it intense (khatarnak): waves of enemies, health, score, hit effects. Use only engine primitives and built-in shapes so no external assets are needed. Code must compile."

    private fun parseFiles(t: String): List<Pair<String, String>> {
        val re = Regex("^=== FILE: (.+?) ===[ \\t]*$", RegexOption.MULTILINE)
        val ms = re.findAll(t).toList()
        val out = mutableListOf<Pair<String, String>>()
        for ((i, m) in ms.withIndex()) {
            val start = m.range.last + 1
            val end = if (i + 1 < ms.size) ms[i + 1].range.first else t.length
            var body = t.substring(start, end).trim('\n', '\r')
            body = body.replace(Regex("^```[a-zA-Z+#]*\\r?\\n"), "").replace(Regex("\\r?\\n```\\s*$"), "")
            val path = m.groupValues[1].trim().replace("..", "").replace('\\', '/').trimStart('/')
            if (path.isNotEmpty()) out.add(path to body)
        }
        return out.distinctBy { it.first }
    }

    private fun saveZip(name: String, files: List<Pair<String, String>>): Uri? {
        val cv = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "${name}_UE5_${System.currentTimeMillis()}.zip")
            put(MediaStore.MediaColumns.MIME_TYPE, "application/zip"); put(MediaStore.MediaColumns.RELATIVE_PATH, "Download/ZORION")
        }
        val u = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv) ?: return null
        contentResolver.openOutputStream(u)?.use { os ->
            ZipOutputStream(os).use { z ->
                files.forEach { (p, c) -> z.putNextEntry(ZipEntry("$name/$p")); z.write(c.toByteArray()); z.closeEntry() }
            }
        }
        return u
    }

    private fun buildUe(q: String) {
        val tv = thinkBubble("Unreal Engine 5 project bana raha hoon, boss… (3-4 minute lag sakte hain)")
        Thread {
            var err = ""
            var files: List<Pair<String, String>>? = null
            var name = "ZorionGame"; var uri: Uri? = null
            try {
                val msgs = JSONArray().put(msg("system", ueSys)).put(msg("user", q))
                val t = llm(msgs, 32000, 290000, buildOrder)
                val fl = parseFiles(t)
                if (fl.size < 4) throw Exception("bad output")
                files = fl
                name = fl.firstOrNull { it.first.endsWith(".uproject") }?.first?.substringAfterLast('/')?.removeSuffix(".uproject")
                    ?.replace(Regex("[^A-Za-z0-9_]"), "")?.ifBlank { null } ?: "ZorionGame"
                uri = saveZip(name, fl)
            } catch (e: Exception) { err = e.message ?: "" }
            runOnUiThread {
                val fl = files
                if (fl == null) {
                    val m = if (err == "NOKEY") "Boss, pehle settings (⚙) mein API key daalo." else "UE5 project nahi ban paya, boss. Phir se try karo."
                    settle(tv, m); speak(m)
                } else {
                    settle(tv, "UE5 project ready, boss! ${fl.size} files · $name\nZip: Downloads/ZORION. PC pe copy karke unzip karo aur .uproject kholo (Unreal Engine 5.4).")
                    speak("UE5 project ready, boss. Zip Downloads ZORION folder mein hai. PC pe khol lo.")
                    uri?.let { u -> actionBubble("↗ Zip share karo") { shareUri(u, "application/zip") } }
                    fl.firstOrNull { it.first.equals("README.md", true) }?.let { r -> actionBubble("📄 README (steps)") { showText("README", r.second) } }
                    actionBubble("📂 Saari files") { showText("$name files", fl.joinToString("\n") { "${it.first}  (${it.second.length} chars)" }) }
                }
            }
        }.start()
    }

    // ================= generate photos =================
    private fun isImage(q: String): Boolean {
        val l = q.lowercase()
        return Regex("\\b(image|photo|picture|pic|tasveer|wallpaper|poster|logo)\\b|फोटो|तस्वीर").containsMatchIn(l) &&
            Regex("banao|bana do|bana de|generate|\\bmake\\b|\\bcreate\\b|\\bdraw\\b|बनाओ|बना दो").containsMatchIn(l)
    }

    private fun genImage(q: String) {
        hud.mode = 2
        val tv = thinkBubble("Image bana raha hoon, boss…")
        Thread {
            var bmp: Bitmap? = null
            try { bmp = geminiImage(q) } catch (e: Exception) { }
            if (bmp == null) try { bmp = freeImage(q) } catch (e: Exception) { }
            runOnUiThread {
                val b = bmp
                if (b == null) { settle(tv, "Image nahi ban paayi, boss."); speak("Image nahi ban paayi, boss.") }
                else {
                    settle(tv, "Ye lo, boss."); speak("Ye lo, boss.")
                    log.addView(ImageView(this).apply { setImageBitmap(b); adjustViewBounds = true },
                        LinearLayout.LayoutParams(dp(260), -2).apply { gravity = Gravity.START; setMargins(0, dp(4), 0, dp(4)) })
                    val cv = ContentValues().apply {
                        put(MediaStore.MediaColumns.DISPLAY_NAME, "zorion_${System.currentTimeMillis()}.jpg")
                        put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg"); put(MediaStore.MediaColumns.RELATIVE_PATH, "Pictures/ZORION")
                    }
                    val u = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv)
                    if (u != null) {
                        contentResolver.openOutputStream(u)?.use { b.compress(Bitmap.CompressFormat.JPEG, 92, it) }
                        actionBubble("↗ Share image") { shareUri(u, "image/jpeg") }
                    }
                }
            }
        }.start()
    }

    private fun geminiImage(q: String): Bitmap? {
        val key = prefs.getString("gemini", "") ?: ""
        if (key.isBlank()) return null
        val body = JSONObject().put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", "Generate an image: $q")))))
            .put("generationConfig", JSONObject().put("responseModalities", JSONArray().put("TEXT").put("IMAGE")))
        val c = URL("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-image:generateContent").openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.doOutput = true; c.connectTimeout = 15000; c.readTimeout = 90000
        c.setRequestProperty("Content-Type", "application/json"); c.setRequestProperty("x-goog-api-key", key)
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        if (c.responseCode !in 200..299) return null
        val parts = JSONObject(c.inputStream.bufferedReader().readText()).getJSONArray("candidates").getJSONObject(0)
            .getJSONObject("content").getJSONArray("parts")
        for (i in 0 until parts.length()) {
            val inl = parts.getJSONObject(i).optJSONObject("inlineData") ?: continue
            val b = Base64.decode(inl.getString("data"), Base64.DEFAULT)
            return BitmapFactory.decodeByteArray(b, 0, b.size)
        }
        return null
    }

    // free fallback (no key): prompt is sent to pollinations.ai
    private fun freeImage(q: String): Bitmap? {
        val c = URL("https://image.pollinations.ai/prompt/" + Uri.encode(q) + "?width=768&height=768&nologo=true").openConnection() as HttpURLConnection
        c.connectTimeout = 15000; c.readTimeout = 90000
        if (c.responseCode !in 200..299) return null
        val b = c.inputStream.readBytes()
        return BitmapFactory.decodeByteArray(b, 0, b.size)
    }

    override fun onDestroy() { live = false; stopSpeaking(); sr?.destroy(); tts?.shutdown(); super.onDestroy() }
}
