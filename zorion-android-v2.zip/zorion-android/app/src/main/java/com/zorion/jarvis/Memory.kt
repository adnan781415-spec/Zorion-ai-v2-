package com.zorion.jarvis

import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

/**
 * ZORION long-term memory (stored encrypted via the prefs passed in).
 *  - facts   : durable things about the user (name, likes, projects...). Max 100.
 *  - summary : rolling summary of old conversation, so nothing important is lost.
 *  - history : recent raw messages (role to text).
 */
class Memory(private val prefs: SharedPreferences) {
    private val facts = mutableListOf<String>()
    var summary = ""
        private set
    private val hist = mutableListOf<Pair<String, String>>()

    init {
        try {
            val a = JSONArray(prefs.getString("facts", "[]"))
            for (i in 0 until a.length()) facts.add(a.getString(i))
        } catch (e: Exception) { }
        // migrate the old single-string memory
        val old = (prefs.getString("mem", "") ?: "").trim()
        if (old.isNotEmpty()) {
            old.lines().map { it.removePrefix("- ").trim() }.filter { it.isNotEmpty() }.forEach { addFact(it, false) }
            prefs.edit().remove("mem").apply()
        }
        summary = prefs.getString("sum", "") ?: ""
        try {
            val a = JSONArray(prefs.getString("hist", "[]"))
            for (i in 0 until a.length()) { val o = a.getJSONObject(i); hist.add(o.getString("r") to o.getString("t")) }
        } catch (e: Exception) { }
        save()
    }

    @Synchronized fun snapshot(): List<String> = facts.toList()
    @Synchronized fun recent(n: Int): List<Pair<String, String>> = hist.takeLast(n)
    @Synchronized fun historySize(): Int = hist.size
    @Synchronized fun oldest(n: Int): List<Pair<String, String>> = hist.take(n)

    @Synchronized fun addFact(f: String, persist: Boolean = true): Boolean {
        val s = f.trim().trimEnd('.', ' ')
        if (s.length < 3 || facts.any { it.equals(s, true) }) return false
        facts.add(s)
        while (facts.size > 100) facts.removeAt(0)
        if (persist) save()
        return true
    }

    @Synchronized fun forget(key: String): Int {
        val n = facts.count { it.contains(key, true) }
        facts.removeAll { it.contains(key, true) }
        save(); return n
    }

    @Synchronized fun removeAt(i: Int) { if (i in facts.indices) { facts.removeAt(i); save() } }

    @Synchronized fun clearAll() { facts.clear(); hist.clear(); summary = ""; save() }

    @Synchronized fun addTurn(user: String, ai: String) {
        hist.add("user" to user); hist.add("assistant" to ai)
        while (hist.size > 90) hist.removeAt(0) // hard cap if summarising keeps failing
        save()
    }

    /** Replace the oldest [n] messages with a fresh [newSummary]. */
    @Synchronized fun compact(n: Int, newSummary: String) {
        repeat(minOf(n, hist.size)) { hist.removeAt(0) }
        summary = newSummary
        save()
    }

    @Synchronized fun promptBlock(): String {
        val sb = StringBuilder()
        if (facts.isNotEmpty()) sb.append("\nLONG-TERM MEMORY (facts about the user, use naturally):\n").append(facts.joinToString("\n") { "- $it" })
        if (summary.isNotBlank()) sb.append("\nEARLIER CONVERSATION SUMMARY:\n").append(summary)
        return sb.toString()
    }

    private fun save() {
        val h = JSONArray()
        hist.forEach { h.put(JSONObject().put("r", it.first).put("t", it.second)) }
        prefs.edit().putString("facts", JSONArray(facts).toString()).putString("sum", summary).putString("hist", h.toString()).apply()
    }
}
